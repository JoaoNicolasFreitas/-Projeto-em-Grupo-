package com.example.demo.controllers;

import com.example.demo.entities.Pagamento;
import com.example.demo.services.PagamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pagamentos")
public class PagamentoController {
    @Autowired
    private PagamentoService pagamentoService;

    @PostMapping
    public Pagamento salvarPagamento(@RequestBody Pagamento pagamento) {
        return pagamentoService.salvarPagamento(pagamento);
    }

    @GetMapping
    public List<Pagamento> listarPagamentos() {
        return pagamentoService.buscarTodosPagamentos();
    }

    // Outros endpoints
}

