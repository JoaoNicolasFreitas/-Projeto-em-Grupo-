package com.example.demo.services;

import com.example.demo.entities.Pagamento;
import com.example.demo.repositories.PagamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class PagamentoService {
    @Autowired
    private PagamentoRepository pagamentoRepository;

    public Pagamento salvarPagamento(Pagamento pagamento) {
        return pagamentoRepository.save(pagamento);
    }

    public List<Pagamento> buscarTodosPagamentos() {
        return pagamentoRepository.findAll();
    }
}
