package com.example.demo.entities;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

public class MetodoPagamento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long metodoPagamentoID;

    private String descricao;

    public Long getMetodoPagamentoID() {
        return metodoPagamentoID;
    }

    public void setMetodoPagamentoID(Long metodoPagamentoID) {
        this.metodoPagamentoID = metodoPagamentoID;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}
