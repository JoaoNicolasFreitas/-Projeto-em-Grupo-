package com.example.demo.entities;


import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.Date;

@Entity
    public class Pagamento {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long pagamentoID;

        private BigDecimal valorPago;
        private Date dataPagamento;
        private String statusPagamento;

        @ManyToOne
        @JoinColumn(name = "MetodoPagamentoID")
        private MetodoPagamento metodoPagamento;

        @ManyToOne
        @JoinColumn(name = "ClienteID")
        private Cliente cliente;

    public Long getPagamentoID() {
        return pagamentoID;
    }

    public void setPagamentoID(Long pagamentoID) {
        this.pagamentoID = pagamentoID;
    }

    public BigDecimal getValorPago() {
        return valorPago;
    }

    public void setValorPago(BigDecimal valorPago) {
        this.valorPago = valorPago;
    }

    public Date getDataPagamento() {
        return dataPagamento;
    }

    public void setDataPagamento(Date dataPagamento) {
        this.dataPagamento = dataPagamento;
    }

    public String getStatusPagamento() {
        return statusPagamento;
    }

    public void setStatusPagamento(String statusPagamento) {
        this.statusPagamento = statusPagamento;
    }

    public MetodoPagamento getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(MetodoPagamento metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}


