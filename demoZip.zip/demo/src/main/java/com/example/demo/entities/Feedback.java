package com.example.demo.entities;

public class Feedback {
}
